<?php get_header(); ?>
<section class="hero paper">
  <div class="container hero-inner">
    <div class="hero-copy">
      <h1>Fresh flowers, crafted with care</h1>
      <p>Seasonal bouquets and arrangements. Custom orders and cozy workshops.</p>
      <div class="actions">
        <a class="btn" href="<?php echo esc_url( get_permalink( wc_get_page_id('shop') ) ); ?>">Shop bouquets</a>
        <a class="btn alt" href="<?php echo esc_url( get_permalink( get_page_by_path('classes') ) ); ?>">Book a workshop</a>
      </div>
    </div>
    <figure class="hero-image cyanotype cyanotype--heavy">
      <?php if ( has_post_thumbnail() ) { $id = get_post_thumbnail_id(); $src = wp_get_attachment_image_url($id, 'full'); echo '<img data-src="'.esc_url($src).'" alt="'.esc_attr(get_the_title()).'">'; } else { echo '<div class="img-fallback">Add a Featured Image to the front page</div>'; } ?>
    </figure>
  </div>
</section>
<section id="gallery" class="section">
  <div class="container">
    <div class="section-head"><h2>Gallery</h2><p class="muted">Recent work</p></div>
    <div class="grid gallery-grid">
      <?php $q=new WP_Query(['posts_per_page'=>9,'post_status'=>'publish','ignore_sticky_posts'=>true,'category_name'=>'gallery']);
      if($q->have_posts()): while($q->have_posts()):$q->the_post();
        echo '<article class="card" onclick="llbOpenLightbox(this)" data-caption="'.esc_attr(get_the_title()).'">';
        if(has_post_thumbnail()){ $id=get_post_thumbnail_id(); llb_cyano_img($id,get_the_title(),'large'); } else { echo '<div class="img-fallback">Set a Featured Image</div>'; }
        echo '<div class="pad"><strong>'.esc_html(get_the_title()).'</strong></div></article>';
      endwhile; wp_reset_postdata(); else: echo '<p>Add posts in the "gallery" category with featured images.</p>'; endif; ?>
    </div>
  </div>
</section>
<section id="shop" class="section paper"><div class="container"><div class="section-head"><h2>Shop</h2><p>Pickup and local delivery available</p></div><div class="grid product-grid"><?php echo do_shortcode('[products limit="8" columns="4"]'); ?></div></div></section>
<section id="classes" class="section"><div class="container"><div class="section-head"><h2>Workshops</h2><p>All levels. Tools and flowers provided</p></div><div class="grid class-grid"><?php echo do_shortcode('[events_list limit=6 pagination=1]'); ?></div></div></section>
<section id="about" class="section paper"><div class="container split"><div><h2>About</h2><p>Lovelily Blooms is a small floral studio. We source seasonal stems and arrange with a light, airy touch.</p><p>Custom bouquets and event florals available by request.</p></div><figure class="cyanotype"><div class="img-fallback">Add an image or keep this texture</div></figure></div></section>
<?php get_footer(); ?>
