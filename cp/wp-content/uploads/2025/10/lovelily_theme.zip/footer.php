<?php ?>
</main>
<footer class="site-footer paper">
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> Lovelily Blooms. All rights reserved.</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
